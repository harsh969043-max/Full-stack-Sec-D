const express = require("express");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error("JWT_SECRET is missing. Add it to your .env file.");
}

// Demo storage: users are stored in memory and reset when the server restarts.
const users = new Map();

// POST /register
app.post("/register", (req, res) => {
  const { username, password } = req.body || {};

  if (
    typeof username !== "string" ||
    !username.trim() ||
    typeof password !== "string" ||
    password.length < 6
  ) {
    return res.status(400).json({ error: "Invalid input" });
  }

  const normalizedUsername = username.trim();

  if (users.has(normalizedUsername)) {
    return res.status(409).json({ error: "Username already exists" });
  }

  users.set(normalizedUsername, password);

  return res.status(201).json({ message: "User registered" });
});

// POST /login
app.post("/login", (req, res) => {
  const { username, password } = req.body || {};

  if (
    typeof username !== "string" ||
    typeof password !== "string" ||
    !users.has(username.trim()) ||
    users.get(username.trim()) !== password
  ) {
    return res.status(401).json({ error: "Invalid credentials" });
  }

  const token = jwt.sign(
    { username: username.trim() },
    JWT_SECRET,
    { expiresIn: "1h" }
  );

  return res.status(200).json({ token });
});

// Middleware: verify Bearer JWT
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const token = authHeader.slice("Bearer ".length).trim();

  if (!token) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (
      err ||
      !decoded ||
      typeof decoded !== "object" ||
      typeof decoded.username !== "string"
    ) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    req.user = decoded;
    return next();
  });
}

// GET /profile (protected)
app.get("/profile", authenticateToken, (req, res) => {
  return res.status(200).json({ username: req.user.username });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
