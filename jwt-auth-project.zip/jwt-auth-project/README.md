# JWT Authentication Project

## Features
- `POST /register` validates username and password and rejects duplicates.
- `POST /login` returns a JWT that expires in one hour.
- `GET /profile` requires `Authorization: Bearer <token>`.

## Requirements
- Node.js (LTS recommended)
- npm

## Setup (Windows PowerShell / VS Code terminal)
1. Extract this ZIP.
2. Open the extracted `jwt-auth-project` folder in VS Code.
3. Copy `.env.example` to `.env` and set a private `JWT_SECRET`.
4. Install packages:
   ```bash
   npm install
   ```
5. Start:
   ```bash
   npm start
   ```
6. Server URL: `http://localhost:3000`

## Test with Postman

### Register
- Method: POST
- URL: `http://localhost:3000/register`
- Body > raw > JSON:
  ```json
  {"username":"harsh","password":"harsh123"}
  ```
- Expected: `201` and `{"message":"User registered"}`

### Login
- Method: POST
- URL: `http://localhost:3000/login`
- Body > raw > JSON:
  ```json
  {"username":"harsh","password":"harsh123"}
  ```
- Expected: `200` and a `token` value.

### Profile
- Method: GET
- URL: `http://localhost:3000/profile`
- Authorization tab > Bearer Token: paste the token from login.
- Expected: `200` and `{"username":"harsh"}`

## Required error cases
- Invalid registration input: `400 {"error":"Invalid input"}`
- Duplicate username: `409 {"error":"Username already exists"}`
- Unknown user / wrong password: `401 {"error":"Invalid credentials"}`
- Missing, malformed, invalid-signature, or expired token: `401 {"error":"Unauthorized"}`

## Notes
This is a classroom demonstration. Users are stored in memory and are lost when the server restarts. Passwords are stored as plain text in this demo; production apps should hash passwords (e.g. bcrypt) and use a persistent database. Keep `.env` secret and do not commit it to GitHub.
