import React from "react";
import Cart from "./Cart";

export default function App() {
  const products = [
    { id: 1, name: "T-Shirt", price: 500 },
    { id: 2, name: "Shoes", price: 800 },
    { id: 3, name: "Watch", price: 300 },
  ];

  return <Cart products={products} />;
}
