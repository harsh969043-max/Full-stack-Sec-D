import React, { useState } from "react";

export default function Cart({ products = [] }) {
  const [cart, setCart] = useState({});

  const addToCart = (product) => {
    setCart((prev) => ({
      ...prev,
      [product.id]: {
        ...product,
        quantity: (prev[product.id]?.quantity || 0) + 1,
      },
    }));
  };

  const increaseQty = (id) => {
    setCart((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        quantity: prev[id].quantity + 1,
      },
    }));
  };

  const decreaseQty = (id) => {
    setCart((prev) => {
      if (!prev[id]) return prev;

      if (prev[id].quantity <= 1) {
        const updated = { ...prev };
        delete updated[id];
        return updated;
      }

      return {
        ...prev,
        [id]: {
          ...prev[id],
          quantity: prev[id].quantity - 1,
        },
      };
    });
  };

  const removeItem = (id) => {
    setCart((prev) => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };

  const items = Object.values(cart);
  const total = items.reduce(
    (sum, item) => sum + Number(item.price) * item.quantity,
    0
  );

  // Apply a 10% discount when the subtotal is 1000 or more.
  const discount = total >= 1000 ? total * 0.1 : 0;
  const grandTotal = total - discount;

  return (
    <div>
      <h2>Shopping Cart</h2>

      <h3>Products</h3>
      {products.map((product) => (
        <div key={product.id}>
          <span>
            {product.name} - {Number(product.price).toFixed(2)}
          </span>{" "}
          <button
            data-testid={`add-${product.id}`}
            onClick={() => addToCart(product)}
          >
            Add to Cart
          </button>
        </div>
      ))}

      <hr />
      <h3>Your Cart</h3>

      {items.length === 0 ? (
        <p data-testid="cart-empty">Cart is empty</p>
      ) : (
        items.map((item) => (
          <div key={item.id}>
            <span>{item.name} </span>
            <span data-testid={`qty-${item.id}`}>{item.quantity}</span>{" "}
            <button
              data-testid={`inc-${item.id}`}
              onClick={() => increaseQty(item.id)}
            >
              +
            </button>{" "}
            <button
              data-testid={`dec-${item.id}`}
              onClick={() => decreaseQty(item.id)}
            >
              -
            </button>{" "}
            <button
              data-testid={`remove-${item.id}`}
              onClick={() => removeItem(item.id)}
            >
              Remove
            </button>
          </div>
        ))
      )}

      <hr />
      <p data-testid="total">Total: {total.toFixed(2)}</p>

      {discount > 0 && (
        <>
          <p data-testid="discount">Discount: {discount.toFixed(2)}</p>
          <p data-testid="grand-total">
            Grand Total: {grandTotal.toFixed(2)}
          </p>
        </>
      )}
    </div>
  );
}
