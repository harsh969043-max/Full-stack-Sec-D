# Practical B2: Shopping Cart with Discount (React)

## Files
- `src/Cart.jsx`: Required default-export Cart component.
- `src/App.jsx`: Demo app with sample products.

## Run
Copy `src/Cart.jsx` into the `src` folder of your existing React project. You can use the provided `App.jsx` as a demo, then run:

```bash
npm install
npm run dev
```

For Create React App, use `npm start`.

## Discount rule
This implementation applies a 10% discount when the subtotal is at least 1000. Adjust the threshold/percentage if your instructor specified a different rule.
